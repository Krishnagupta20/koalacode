# koalacode/__init__.py
__version__ = "0.1.0"
__author__ = "Krishna Gupta"
