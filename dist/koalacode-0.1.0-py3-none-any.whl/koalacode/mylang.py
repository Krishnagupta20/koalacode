import sys
from lexer import tokenize
from parser import Parser
from interpreter import Interpreter, RuntimeError_

def run_code(code, interp):
    """Tokenize, parse, and evaluate MyLang code."""
    try:
        tokens = tokenize(code)
        parser = Parser(tokens)
        ast = parser.parse()
        return interp.eval(ast)
    except RuntimeError_ as e:
        # Our custom runtime errors (with line/col info)
        print("Runtime Error:", e)
    except Exception as e:
        # Fallback for unexpected Python exceptions
        print("Internal Error:", e)


if __name__ == '__main__':
    interp = Interpreter()

    # Run from file
    if len(sys.argv) > 1:
        with open(sys.argv[1]) as f:
            code = f.read()
        run_code(code, interp)

    # REPL mode
    else:
        print("MyLang REPL. End with ';'. Ctrl-C to exit.")
        buf = ''
        while True:
            try:
                line = input('>>> ')
            except KeyboardInterrupt:
                print("\nExiting MyLang.")
                break

            buf += line + '\n'

            # Only run code after semicolon or closing brace
            if line.strip().endswith(';') or line.strip().endswith('}'):
                run_code(buf, interp)
                buf = ''
