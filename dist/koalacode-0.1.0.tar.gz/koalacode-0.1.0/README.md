# KoalaCode

Small toy programming language.

Install locally:
```bash
pip install -e .
