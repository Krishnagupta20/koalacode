# KoalaCode

KoalaCode — a toy programming language (interpreter in Python).

## Install locally

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# mac/linux:
source .venv/bin/activate

pip install --upgrade pip
pip install -e .
## Run a program
koalacode examples/test.ko
